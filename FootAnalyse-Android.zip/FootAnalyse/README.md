# Foot Analyse — application Android (13, 14, 15, 16)

Application d'analyse de matchs de football : confrontations directes, probabilité que les deux équipes marquent par mi-temps, mi-temps la plus prolifique, valeur des cotes, gestion de bankroll, journal de paris et calculateur de combinés.

- Android minimum : 13 (API 33)
- Android cible : 16 (API 36), testé pour fonctionner aussi sur 14 et 15
- Connexion internet : API-Football (clé gratuite, 100 requêtes par jour)

## Obtenir l'APK sans ordinateur puissant (GitHub)

1. Créez un compte sur github.com et un nouveau dépôt (privé si vous voulez).
2. Envoyez tout le contenu de ce dossier dans le dépôt (bouton « Add file » → « Upload files »).
3. Ouvrez l'onglet **Actions** : la construction « Construire l'APK » démarre seule (5 à 10 minutes).
4. Quand elle est verte, ouvrez-la et téléchargez **FootAnalyse-apk** en bas de la page.
5. Décompressez, copiez `app-debug.apk` sur le téléphone et installez-le (autorisez « sources inconnues » quand Android le demande).

## Avec Android Studio

Ouvrez le dossier `FootAnalyse` dans Android Studio, attendez la synchronisation, puis **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.

## Activer la connexion internet

1. Créez un compte gratuit sur https://dashboard.api-football.com et copiez votre clé.
2. Dans l'application, onglet **Analyse** → **Connexion internet**, collez la clé.
3. Tapez les deux équipes (nom officiel, ex. « TP Mazembe »), puis :
   - **Récupérer les confrontations** : remplit le tableau avec les scores mi-temps et final ;
   - **Récupérer les cotes du prochain match** : remplit l'onglet Marchés avec la meilleure cote trouvée chez les bookmakers.

Le plan gratuit d'API-Football ne couvre pas toujours toutes les saisons ni les cotes de tous les championnats.

## Modifier l'application

Toute l'interface est dans `app/src/main/assets/index.html`. Le code Android (WebView, connexion réseau) est dans `MainActivity.kt`.

## Important

Aucune application ne garantit des gains. Le bookmaker garde une marge sur chaque cote. L'application aide à ne parier que lorsque la cote semble trop haute par rapport à la probabilité estimée, à limiter les mises et à suivre vos vrais résultats. Fixez une perte maximale et respectez-la.
